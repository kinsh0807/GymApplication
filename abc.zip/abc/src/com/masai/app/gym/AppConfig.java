package com.masai.app.gym;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;



@Configuration
@ComponentScan(basePackages= {"com.masai.app"})


public class AppConfig {
	
	@Bean
	public String getValue()
	{
		return "Hello World";
	}
	
	@Bean
	public Person person()
	{
		Person per=new Person();
		per.setId(101);
		per.setName("Rama");
		per.setEmail("rama@gmail.com");
		per.setAge(25);
		per.setMobile(89328);
		return per;
		
	}
	
	@Bean
	public Gym gym ()
	{
		Gym gm=new Gym();
		gm.setGym_id(201);
		gm.setGym_name("Abhi");
		gm.setMonthly_fee(500);
		return gm;
	}
	
	

}


